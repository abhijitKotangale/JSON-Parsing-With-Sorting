//
//  ViewController.m
//  JSON Parsing With Sorting
//
//  Created by Student 6 on 10/04/17.
//  Copyright © 2017 felix. All rights reserved.
//

#import "ViewController.h"
#import "CustomTableViewCell.h"
#import "NewViewController.h"

@interface ViewController ()
{
    NSIndexPath *index;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Employee List";
    
    [self getURL];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)getURL
{
    NSString *str = @"https://newsapi.org/v1/articles?source=techcrunch&apiKey=efe99de73d1d49608eb3d4e87c536b26";
    NSURL *url = [NSURL URLWithString:str];
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        if (error != nil) {
            
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"Done" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                
                [self dismissViewControllerAnimated:YES completion:nil];
            }];
            
            [alertController addAction:alertAction];
            [self presentViewController:alertController animated:YES completion:nil];
        }
        else
        {
            NSDictionary *mainData = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
            arrayData = [mainData valueForKey:@"articles"];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if ([arrayData count]) {
                    
                    _tableView.delegate = self;
                    _tableView.dataSource = self;
                    [_tableView reloadData];
                }
            });
           
            
        }
    }];
    [dataTask resume];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomTableViewCell *cell = [_tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if (cell == nil) {
        cell = [[CustomTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    NSDictionary *dict = [arrayData objectAtIndex:indexPath.row];
    dispatch_queue_t objThread=dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0);
    
    // code for image
    dispatch_async(objThread, ^{
        NSString *strImg = [NSString stringWithFormat:@"%@", [dict valueForKey:@"urlToImage"]];
        NSURL *urlImg = [NSURL URLWithString:strImg];
        NSData *dataImg = [NSData dataWithContentsOfURL:urlImg];
        UIImage *img = [UIImage imageWithData:dataImg];
        if (img) {
            dispatch_async(dispatch_get_main_queue(), ^{
                cell.imgView.image=img;
                
            });
        }
    });
 
   
   
    
    //code for label
    cell.lblAuthor.text = [NSString stringWithFormat:@"%@", [dict valueForKey:@"author"]];
    cell.lblTitle.text = [NSString stringWithFormat:@"%@", [dict valueForKey:@"title"]];
    cell.lblDescription.text = [NSString stringWithFormat:@"%@", [dict valueForKey:@"publishedAt"]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    index = indexPath;
    [self performSegueWithIdentifier:@"FirstToSecond" sender:self];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{

    if ([segue.identifier isEqualToString:@"FirstToSecond"]) {
        
        NewViewController *obj = [segue destinationViewController];
        
        NSDictionary *dictNew = [arrayData objectAtIndex:index.row];
        
        // code for img
        NSString *strImgNew = [NSString stringWithFormat:@"%@", [dictNew valueForKey:@"urlToImage"]];
        NSURL *urlImgNew = [NSURL URLWithString:strImgNew];
        NSData *dataImgNew = [NSData dataWithContentsOfURL:urlImgNew];
        UIImage *imgNew = [UIImage imageWithData:dataImgNew];
        
        obj.img = imgNew;
        
        obj.lblFirst = [NSString stringWithFormat:@"%@", [dictNew valueForKey:@"author"]];
        obj.lblSecond = [NSString stringWithFormat:@"%@", [dictNew valueForKey:@"title"]];
        obj.lblThird = [NSString stringWithFormat:@"%@", [dictNew valueForKey:@"publishedAt"]];
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)sortingById:(id)sender {
    
    NSSortDescriptor *sortID = [NSSortDescriptor sortDescriptorWithKey:@"publishedAt" ascending:YES];
    arrayData = [arrayData sortedArrayUsingDescriptors:@[sortID]];
    [_tableView reloadData];
}

- (IBAction)sortingByTitle:(id)sender {
    
    NSSortDescriptor *sordTitle = [NSSortDescriptor sortDescriptorWithKey:@"title" ascending:YES];
    arrayData = [arrayData sortedArrayUsingDescriptors:@[sordTitle]];
    [_tableView reloadData];
}
@end
