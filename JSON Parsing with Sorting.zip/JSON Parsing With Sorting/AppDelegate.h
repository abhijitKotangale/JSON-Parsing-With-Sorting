//
//  AppDelegate.h
//  JSON Parsing With Sorting
//
//  Created by Student 6 on 10/04/17.
//  Copyright © 2017 felix. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

