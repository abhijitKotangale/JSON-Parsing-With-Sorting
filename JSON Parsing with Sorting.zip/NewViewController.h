//
//  NewViewController.h
//  JSON Parsing With Sorting
//
//  Created by Student 6 on 10/04/17.
//  Copyright © 2017 felix. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *NewImgView;
@property (weak, nonatomic) IBOutlet UILabel *lblNewAuthor;
@property (weak, nonatomic) IBOutlet UILabel *lblNewTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblNewDescription;

@property (strong, nonatomic)UIImage *img;
@property (strong, nonatomic)NSString *lblFirst;
@property (strong, nonatomic)NSString *lblSecond;
@property (strong, nonatomic)NSString *lblThird;

@end
